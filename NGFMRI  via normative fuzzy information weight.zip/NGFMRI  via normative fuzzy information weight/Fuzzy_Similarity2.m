function[similarity_matrix]=Fuzzy_Similarity2(data)

%min,max
[m,n] = size(data);
similarity_matrix = zeros(m,m,n);
std_a = std(data(:,1:n));
%max(min(a,b),c)=min(max(a,c),max(b,c))
T=ones(1,m);
for k=1:n
    A=1+(1/std_a(k))*(T'*data(:,k)'-data(:,k)*T);
    Anew=A.*(A>0);
    B=1-(1/std_a(k))*(T'*data(:,k)'-data(:,k)*T);
    Bnew=B.*(B>0);
    index=Anew<=Bnew;

    %disp(index);
    C=zeros(m,m);
    C(index)=Anew(index);
    C(~index)=Bnew(~index);
    similarity_matrix(:,:,k)=C;
end