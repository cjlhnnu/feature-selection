function [gran_feat_gain,gran_feat_con]=Feature_Select_Gran_new(source_data,tag,alpha)
% tag is the option of similarity matrix
exp_data=normalization(source_data)   %it is used to normalize the original data
n = size(data,2);
C = zeros((n-1),1);
for i = 1:size(C)
    C(i) = i;
end
D = n;
%% Similarity matrix
switch tag
    case 1
        similarity_matrix = Fuzzy_Similarity(exp_data);       %Gaussian
    case 2
        similarity_matrix = Fuzzy_Similarity1(exp_data);      %1-4*|xi-xj|
    case 3
        similarity_matrix = Fuzzy_Similarity2(exp_data);      %min��max
end;
%%
con_ent_all =Fuzzy_Gran_Conditional_Entropy(similarity_matrix,C,D)   
con_ent = 100;
reduct=[];
gran_feat_gain=[];
polt1=[];
unSelect=zeros(1,(n-1));      %
con_ent_prev = 1000;
%while  con_ent-con_ent_all >0.01    
%while con_ent < (con_ent_prev-0.005)
%while con_ent < (con_ent_prev-0.0001)
while con_ent < (con_ent_prev-alpha) 
    %feat_gain=reduct
    max_sig = -100;
    index = 0;
    for i = 1:(n-1)
        if unSelect(i) == 0
            sig = Gran_Feat_Gain_Ratio(similarity_matrix,reduct,D,i);
            if sig > max_sig
                max_sig = sig;
                index = i;
            end
        end
    end
    if index==0
        reduct=reduct;
        con_ent_prev=con_ent;
    else
    unSelect(index) = 1;
    con_ent_prev = con_ent;
    %index
    %con_ent = Fuzzy_Gran_Conditional_Entropy(similarity_matrix,[reduct;index],D);
   %if con_ent_prev-con_ent<0.01
    %    reduct=reduct;
    %    con_ent = con_ent_prev;
    %else
        reduct=[reduct,index];
        con_ent = Fuzzy_Gran_Conditional_Entropy(similarity_matrix,reduct,D);
        polt1=[polt1,con_ent];
    %end
    end
    gran_feat_gain=reduct;
    
end
x=polt1;
subplot(1,2,1); plot(x,'*'); grid on;hold on;

%%  
con_ent = 100;
reduct1=[];
gran_feat_con=[];
unSelect=zeros(1,(n-1));
polt2=[];

con_ent_prev=1000;
betar=0.0001;
%while abs(con_ent - con_ent_all) >0.001  %0.1
%while  con_ent-con_ent_all >0.01  
%while con_ent < (con_ent_prev-0.005)
%while con_ent < (con_ent_prev-0.0001)
while con_ent < (con_ent_prev-betar) 
    max_sig = -100;
    index1 = 0;
    for i = 1:(n-1)
        if unSelect(i) == 0
            sig = Gran_Feat_Gain(similarity_matrix,reduct1,D,i);
            if sig > max_sig
                max_sig = sig;
                index1 = i;
            end
        end
    end
    if index1==0
        gran_feat_con=reduct1;
        con_ent_prev=con_ent;
    else
    unSelect(index1) = 1;
    reduct1=[reduct1,index1];
    con_ent_prev = con_ent;
    con_ent = Fuzzy_Gran_Conditional_Entropy(similarity_matrix,[reduct1],D) ;
    %if abs(con_ent_prev-con_ent)<0.0001
    %if (con_ent_prev-con_ent)<0.0001
    %    con_ent=con_ent_prev;
    %else
        polt2=[polt2,con_ent];
    %end
    end
    gran_feat_con=reduct1;
    
end
y=polt2;
subplot(1,2,2); plot(y,'*');grid on;
%csvwrite(['result\' data_name '\' data_name '_gran_feat_con.csv'],tmpdata(:,[gran_feat_con;n]));% ���֪ʶ����
end