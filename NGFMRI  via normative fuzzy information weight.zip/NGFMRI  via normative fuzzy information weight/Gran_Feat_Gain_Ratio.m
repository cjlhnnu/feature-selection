function[ Gran_feat_gain_ratio ]=Gran_Feat_Gain_Ratio(similarity_matrix,C,D,a)
% MRI_Ratio=MRI(ak)/(H(a)+H(D))
m=size(C,1);   %
if m==0           % 2*MRI(ak)/()
   Gran_feat_gain_ratio=2*Mutual_Inf_Gran(similarity_matrix,a,D)/(1-Fuzzy_Gran_Entropy(similarity_matrix,D)+1-Fuzzy_Gran_Entropy(similarity_matrix,a));
else              %MRI(ak)/(D(ak)+D(D))
    Gran_feat_gain_ratio=0;
    for i=1:m    
        if C(i)~=a
            Gran_feat_gain_ratio=Gran_feat_gain_ratio+2*Mutual_Inf_Gran(similarity_matrix,[C(i);a],D)-Mutual_Inf_Gran(similarity_matrix,C(i),D)-Mutual_Inf_Gran(similarity_matrix,a,D);
        end
    end
    Gran_feat_gain_ratio=2*(Gran_feat_gain_ratio+Mutual_Inf_Gran(similarity_matrix,a,D))/(1-Fuzzy_Gran_Entropy(similarity_matrix,D)+1-Fuzzy_Gran_Entropy(similarity_matrix,a));
end