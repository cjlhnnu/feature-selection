function[similarity_matrix]=Fuzzy_Similarity(data)
%Gaussian
[m,n] = size(data);
similarity_matrix = zeros(m,m,n);
std_a = std(data(:,1:n));
T=ones(1,m);
for k=1:n
    similarity_matrix(:,:,k)=exp((-1)*(data(:,k)*T-T'*data(:,k)').^2/(2.*std_a(k).^2));
end
similarity_matrix(:,:,n)=similarity_matrix(:,:,n).*(similarity_matrix(:,:,n)>=1);
