function [f_gran_con_ent] =Fuzzy_Gran_Conditional_Entropy (similarity_matrix,C,D)
if size(C,1)==0
    f_gran_con_ent=1-Fuzzy_Gran_Entropy(similarity_matrix,D);
else
    f_gran_con_ent=Fuzzy_Gran_Entropy (similarity_matrix,C)-Fuzzy_Gran_Entropy(similarity_matrix,[C;D]);
end
end