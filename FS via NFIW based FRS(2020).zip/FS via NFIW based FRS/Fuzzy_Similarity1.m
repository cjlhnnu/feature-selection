function[similarity_matrix]=Fuzzy_Similarity1(data)
%1-4*|xi-xj|    |xi-xj|��0.25
%0              otherwise
[m,n] = size(data);
similarity_matrix = zeros(m,m,n);
min_element=min(data(:,1:n));        %min
max_element=max(data(:,1:n));        %max
T=ones(1,m);
for k=1:n
      diff=abs(data(:,k)*T-T'*data(:,k)')/abs(max_element(k)-min_element(k));
      D = 1-4*diff;      
      similarity_matrix(:,:,k)=D.*(D>0);      
end
