function [ fuzzy_gra_ent ]=Fuzzy_Gran_Entropy(similarity_matrix,R)
n=size(similarity_matrix,1);
tmp_matrix = ones(n,n);
[at_num,~]=size(R);
if at_num==0
    fuzzy_gra_ent=1;
else
for i = 1:at_num         
    tmp_matrix = min(tmp_matrix, similarity_matrix(:,:,R(i)));
end
fuzzy_gra_ent = 0;
for i = 1:n
    sum_i = sum(tmp_matrix(i,:));           
    if sum_i > 0.00001
        fuzzy_gra_ent = fuzzy_gra_ent +(sum_i/n) ;
    end
end
end
fuzzy_gra_ent =fuzzy_gra_ent/n;
end