function[ Gran_feat_gain ]=Gran_Feat_Gain(similarity_matrix,C,D,a)
m=size(C,1);   %
if m==0           % MRI(ak)=I(D;ak)
   Gran_feat_gain=Mutual_Inf_Gran(similarity_matrix,a,D);
else              % MRI(ak)=I(D;ak)+E(ICI[I(D;ai|ak)+I(D;ak|ai)])
    Gran_feat_gain=0;
    for i=1:m    
        if C(i)~=a
            Gran_feat_gain=Gran_feat_gain+2*Mutual_Inf_Gran(similarity_matrix,[C(i);a],D)-Mutual_Inf_Gran(similarity_matrix,C(i),D)-Mutual_Inf_Gran(similarity_matrix,a,D);
        end
    end
    Gran_feat_gain=Gran_feat_gain+Mutual_Inf_Gran(similarity_matrix,a,D);
end
